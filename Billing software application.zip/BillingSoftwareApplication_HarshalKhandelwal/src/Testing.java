import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import com.capgemini.salesmanagement.dao.SaleDAO;

public class Testing {
	
	private SaleDAO daoRef;
	
	@Before
	public void setup()
		{
			System.out.println("setting up dao object");
			daoRef = new SaleDAO();
		}

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	

	@After
	public void tearDown()
	{
		System.out.println("cleaning up dao object");
		System.out.println("-----------------------");
		daoRef=null;
		
	}


}
