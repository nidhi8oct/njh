package com.capgemini.salesmanagement.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.SaleDAO;

public class SaleService implements ISaleService {
	
	SaleDAO daoRef = new SaleDAO();

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		// TODO Auto-generated method stub
		
		return daoRef.insertSalesDetails(sale);
	}

	@Override
	public boolean validateProductCode(int productId) {
		// TODO Auto-generated method stub
		return daoRef.validateProductCode(productId);
	}

	@Override
	public boolean validateQuantity(int qty) {
		// TODO Auto-generated method stub
		return daoRef.validateQuantity(qty);
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		// TODO Auto-generated method stub
		return daoRef.validateProductCat(prodCat);
	}

	@Override
	public boolean validateProductName(String prodName) {
		// TODO Auto-generated method stub
		return daoRef.validateProductName(prodName);
	}

	@Override
	public boolean validateProductPrice(float price) {
		// TODO Auto-generated method stub
		return daoRef.validateProductPrice(price);
	}
	
	

}
