package com.capgemini.salesmanagement.dao;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import com.capgemini.salesmanagement.bean.Sale;

public class SaleDAO implements ISaleDAO {
	
	@Override
	public boolean validateProductCode(int productId) {
		if(productId==1001 || productId==1002 || productId==1003 || productId==1004)
		{
			return true;
		}
		else
		{
		return false;
		}
	}

	@Override
	public boolean validateQuantity(int qty) {
		// TODO Auto-generated method stub
		
		if(qty>0 && qty<5)
		{
			return true;
		}
		else
		{
		return false;
		}
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		// TODO Auto-generated method stub
		
		if(prodCat.equals("Electronics") || prodCat.equals("Toys"))
		{
			return true;
		}
		else
		{
		return false;
		}
	}

	@Override
	public boolean validateProductName(String prodName) {
		// TODO Auto-generated method stub
		
		if(prodName.equals("TV") || prodName.equals("Smart_Phone") || prodName.equals("Video_Game") || prodName.equals("Soft_Toy") || prodName.equals("Telescope") || prodName.equals("Barbee_Doll"))
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public boolean validateProductPrice(float price) {
		// TODO Auto-generated method stub
		
		if(price>200)
		{
			return true;
		}
		else
		{
		return false;
		}
	}

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
		// TODO Auto-generated method stub
		
		
		//System.out.println("salesId is: "+salesId);
		
		return null;
	}

	

}
