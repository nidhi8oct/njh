package com.capgemini.salesmanagement.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.dao.ISaleDAO;

public class CollectionUtil {
	
	public static Map<Integer, Sale> sales = new HashMap<Integer,Sale>();
	public static Map<Integer, Sale> getCollection() 
	{
		return sales;
	}
			
	}