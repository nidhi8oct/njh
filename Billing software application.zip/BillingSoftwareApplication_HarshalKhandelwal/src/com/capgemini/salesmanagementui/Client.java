package com.capgemini.salesmanagementui;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import com.capgemini.salesmanagement.bean.Sale;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ISaleService service = new SaleService();
		Map<Integer, Sale> sale = new HashMap<Integer,Sale>();
		
		int salesId = 100+(int)Math.random();
		int productCode;
		int quantity;
		String productCategory;
		String productName;
		String ProductDescription;
		int productPrice;
		float lineTotal;
		
		Scanner sc = new Scanner(System.in);
		
		
		System.out.println("Enter the product code: ");
		productCode = sc.nextInt();
		boolean flag1 = service.validateProductCode(productCode);
		if(flag1==false)
		{
			System.out.println("Invalid Product Code!!");
			System.exit(0);
		}
		
		
		System.out.println("Enter the quantity: ");
		quantity = sc.nextInt();
		boolean flag2 = service.validateQuantity(quantity);
		if(flag2==false)
		{
			System.out.println("Please enter quantity in the range 0-5");
			System.exit(0);
		}
		
		System.out.println("Enter Product Category from Electronics or Toys: ");
		productCategory = sc.next();
		boolean flag3 = service.validateProductCat(productCategory);
		
		if(flag3==false)
		{
			System.out.println("Invalid product Category: ");
			System.exit(0);
		}
		
		
		System.out.println("Enter Product Name under the following categories: ");
		System.out.println("1. Electronics:\n -TV\n -Smart_Phone\n -Video_Game");
		System.out.println("2. Toys:\n -Soft_Toy\n -Telescope\n -Barbee_Doll");
		productName = sc.next();
		
		if(productCategory.equals("Electronics"))
		{
			
				boolean flag4 = service.validateProductName(productName);
				if(flag4==false)
				{
					System.out.println("Invalid Product Name!!");
					System.exit(0);
				}
		}
		else if(productCategory.equals("Toys"))
		{
			boolean flag4 = service.validateProductName(productName);
			if(flag4==false)
			{
				System.out.println("Invalid Product Name!!");
				System.exit(0);
			}
		}
		else
		{
			System.out.println("Invalid Product Name!!");
			System.exit(0);
		}
		
		
		
		System.out.println("Enter product description: ");
		ProductDescription = sc.next();
		
		System.out.println("Product Price (Rs): ");
		productPrice = sc.nextInt();
		boolean flag5 = service.validateProductPrice(productPrice);
		if(flag5==false)
		{
			System.out.println("Invalid Product Price!!");
			System.out.println("please enter product price greater than Rs.200");
			System.exit(0);
		}
		System.out.println("Line Total (Rs.): "+productPrice*quantity);
		System.out.println("Success");
		System.out.println("Sales id is: "+salesId);
		
		Date date = new Date();
	    String strDateFormat = "hh:mm:ss a";
	    DateFormat dateFormat = new SimpleDateFormat(strDateFormat);
	    String formattedDate= dateFormat.format(date);
	    System.out.println("Current time of the day using Date - 12 hour format: " + formattedDate);

	}

}
