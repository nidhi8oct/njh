import static org.junit.Assert.assertTrue;

import org.junit.Assert;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Login {
	LoginPage page=new LoginPage();

	@Given("^User is on login page$")
	public void user_is_on_login_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		page.goTo();
		Assert.assertTrue(page.isAt());
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		page.goTo();
		
	}

	@Given("^User is on hotel login page$")
	public void user_is_on_hotel_login_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		page.goTo();
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.setFirstname("capgemini");
		Thread.sleep(1000);
		page.setPassword("capg1234");
		Thread.sleep(1000);
		page.setButton();
		Thread.sleep(1000);
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		Browser.driver.navigate().to("file:///D:\\Users\\twinagra\\Desktop\\mvc-project\\eclipse-workspace\\Hotel\\src\\main\\webapp\\hotelbooking.html");
	}

	@When("^user leaves userName blank$")
	public void user_leaves_userName_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.setFirstname("");
		Thread.sleep(1000);
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		page.setButton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user leaves password blank and clicks the button$")
	public void user_leaves_password_blank_and_clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		page.setPassword("");
		page.setButton();
	}

	@When("^user enters incorrect userName$")
	public void user_enters_incorrect_userName() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters incorrect password$")
	public void user_enters_incorrect_password() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
