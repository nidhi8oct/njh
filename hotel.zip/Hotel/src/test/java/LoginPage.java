import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends PathPages{
	private static String url="login.html";
	private static String title="Hotel Booking Application";
	public LoginPage() {
		super(url, title);
		PageFactory.initElements(Browser.driver, this);
		
	}
	
	@FindBy(how = How.NAME, name = "firstName")
	private WebElement firstname;

	@FindBy(how = How.NAME, name = "userPwd" )
	private WebElement password;
	
	@FindBy(how=How.CLASS_NAME, using="btn")
	WebElement button;
	public WebElement getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}

	public String getPassword() {
		return password.getText();
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		button.click();
	}
	

	
	
	


}
