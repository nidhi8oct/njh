package com.capgemini.takehome.ui;

import java.util.Scanner;

import com.capgemini.takehome.service.IProductService;
import com.capgemini.takehome.service.ProductService;
public class Client {
	static int quantity;

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getQuantity() {
		return quantity;
	}
public static void main(String[] args) {
	
	IProductService service=new ProductService();
	Scanner s=new Scanner(System.in);
	System.out.println("Welcome! Enter Your Choice");
	System.out.println("**********MENU**********");
	System.out.println("1.Generate Bill by entering Productcode and quantity.");
	System.out.println("2.Exit");
	int choice=s.nextInt();
	while(true)
	{
	switch(choice)
	{
	case 1:System.out.println("Please Enter the Product Code");
	      String pcode=s.next();
	      if(pcode.length()==4)
	      {
	    	  int product_code=Integer.parseInt(pcode);
	    	  System.out.println("Enter the Quantity");
	    	  quantity=s.nextInt();
	    	  if(quantity>0)
	    	  {
	    		  service.getProductDetails(product_code).toString();
	    	  }
	    	  else
	    	  {
	    		  System.out.println("Enter valid Quantity");
	    	  }
	    	  
	      }
	      else
	      {
	    	  System.out.println("Enter a valid Product");
	      }
	      break;
	case 2:System.out.println("Thanks For Using our App");
	System.exit(0);
	break;
	default: System.out.println("Enter a valid Choice");
	}
}
}
}
