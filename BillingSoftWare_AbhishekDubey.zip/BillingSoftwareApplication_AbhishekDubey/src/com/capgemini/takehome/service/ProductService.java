package com.capgemini.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.dao.IProductDAO;
import com.capgemini.takehome.dao.ProductDAO;

public class ProductService implements  IProductService {
	IProductDAO daoref=new ProductDAO();
	@Override
	public Product getProductDetails(int productCode) {
		return daoref.getProductDetails(productCode);
	}

}
