package com.capgemini.takehome.dao;

import com.capgemini.takehome.bean.Product;

public interface IProductDAO {
	IProductDAO daoref=new ProductDAO();
	Product getProductDetails(int productCode);
}
