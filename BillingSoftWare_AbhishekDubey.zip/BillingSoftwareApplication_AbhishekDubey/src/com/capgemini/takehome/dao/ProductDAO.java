package com.capgemini.takehome.dao;

import com.capgemini.takehome.bean.Product;
import com.capgemini.takehome.exception.ProductNotFoundException;
import com.capgemini.takehome.service.ProductService;
import com.capgemini.takehome.util.CollectionUtil;
import com.capgemini.takehome.exception.*;

public class ProductDAO implements IProductDAO{

	@Override
	public Product getProductDetails(int productCode) {
		
			// TODO Auto-generated method stub
			if(CollectionUtil.getProducts().get(productCode)==null)
			{
				try
				{
					throw new ProductNotFoundException();
				}
				catch(Exception e)
				{
					System.out.println("Sorry! The product code<<"+productCode+">> is not available");
				}
			}
				return CollectionUtil.getProducts().get(productCode);
			}
			
	

}
