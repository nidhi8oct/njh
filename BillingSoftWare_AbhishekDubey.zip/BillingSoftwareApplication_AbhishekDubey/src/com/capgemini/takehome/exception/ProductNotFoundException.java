package com.capgemini.takehome.exception;

public class ProductNotFoundException extends Exception{
	
}