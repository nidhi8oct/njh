package com.capgemini.exception;

public class DuplicatePhoneNo extends Exception {

}
