package com.capgemini.exception;

@SuppressWarnings("serial")
public class InsufficientBalException extends Exception{

}
