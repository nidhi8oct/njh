package com.cg.exception;

public class NotfoundException extends Exception 
{
	public NotfoundException(String s)
	{
		super(s);
	}

}
