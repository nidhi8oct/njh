package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.exception.NotfoundException;
import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao 
{
	Map<String, Account> accountEntry;
	
	public AccountDaoImpl()
	{
		accountEntry = new HashMap<>();
		accountEntry.put("9010210131", new Account("Prepaid","vaishali",200));
		accountEntry.put("9823920123", new Account("Prepaid","megha",453));
		accountEntry.put("9932012345", new Account("Prepaid","vikas",631));
		accountEntry.put("9010210132", new Account("Prepaid","anju",521));
		accountEntry.put("9010210133", new Account("Prepaid","tushar",632));
	}

	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		
		Account flag = accountEntry.get(mobileNo);
		if(flag==null)
		{
			try
			{
				throw new NotfoundException(mobileNo);
			}
			catch(NotfoundException e)
			{
				e.printStackTrace();
			}
		}
		return accountEntry.get(mobileNo);
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		// TODO Auto-generated method stub
		Account flag = accountEntry.get(mobileNo);
		if(flag==null)
		{
			try
			{
			throw new NotfoundException(mobileNo);
			}
			
		catch(NotfoundException e)
		{
			e.printStackTrace();
		}
			return 0;
		}
		else
		{
			Account a = accountEntry.get(mobileNo);
			a.setAccountBalance(a.getAccountBalance()+rechargeAmount);
			a=accountEntry.get(mobileNo);	
			accountEntry.put(mobileNo, a);
			System.out.println("Hello "+a.getCustomerName()+"\n"+"Available Balance: "+a.getAccountBalance());
		}
		
		return 1;
	}
	
	
}
