package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
	
	AccountDaoImpl daoRef = new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return daoRef.getAccountDetails(mobileNo);
	}

	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		// TODO Auto-generated method stub
		return daoRef.rechargeAccount(mobileNo, rechargeAmount);
	}
	

}
