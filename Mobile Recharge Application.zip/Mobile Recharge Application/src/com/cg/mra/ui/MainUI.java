package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		
		String mobileNo,mobileNo1;
		double rechargeAmount;
		
		AccountService service = new AccountServiceImpl();
		
		while(true)
		{
		System.out.println("1. Account Balance Enquiry");
		System.out.println("2. Recharge Account");
		System.out.println("3. Exit");
		
		System.out.println("enter your choice: ");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		switch(choice)
		{
		case 1: System.out.println("enter mobile number: ");
		mobileNo = sc.next();
		char ch[] = mobileNo.toCharArray();
		if(ch.length!=10)
		{
			System.out.println("please enter a valid mobile number!");
		}
		else
		{
			System.out.println(service.getAccountDetails(mobileNo));
		}
		break;
		
		case 2: System.out.println("enter the mobile number: ");
		mobileNo1 = sc.next();
		System.out.println("enter the amount to be reacharged: ");
		rechargeAmount = sc.nextDouble();
		char ch1[] = mobileNo1.toCharArray();
		if(ch1.length!=10)
		{
			System.out.println("please enter a valid mobile number!");
		}
		else
		{
			int flag=service.rechargeAccount(mobileNo1, rechargeAmount);
			if(flag==1)
			{
				System.out.println("Recharge Amount Successfull\n");
			}
		}
		break;
		
		case 3: System.out.println("Thanks for using our system!!\n");
		System.exit(0);
		break;
		
		}
		}

	}

}
