import static org.junit.Assert.*;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class loginpage {
	WebDriver driver;
	public loginpage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how = How.NAME, name = "userName")
	WebElement username;
	
	@FindBy(how = How.NAME, name = "userPwd")
	WebElement userpass;
	
	@FindBy(how = How.CLASS_NAME, using = "btn")
	WebElement button;

	public String getUsername() {
		return username.getText();
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getUserpass() {
	 return userpass.getText();
	}

	public void setUserpass(String userpass) {
		this.userpass.sendKeys(userpass);
	}

	public WebElement getButton() {
		return button;
	}

	public void setButton() {
		this.button.click();;
	}
	
	
	
	
	
	
	
}
