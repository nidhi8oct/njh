import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {
	WebDriver driver;
	loginpage page;
	@Before	
	public void setup()
	{
		String projectLocation = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectLocation+"\\lib\\chromedriver.exe");
		driver =new ChromeDriver();
		page =new loginpage(driver);
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	@Given("^User is on hotel login page$")
	public void user_is_on_hotel_login_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		driver.get("D:\\Users\\twinagra\\Desktop\\mvc-project\\eclipse-workspace\\fghfcgh\\src\\main\\webapp\\login.html");
	}
	

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		String title=driver.findElement(By.xpath("//*[@id=\"mainCnt\"]/div/div[1]/h1")).getText();
		if(title.equals("Hotel Booking Application"))
			System.out.println("matched");
		else
			System.out.println("Not matched");
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.setUsername("capgemini");
		 Thread.sleep(1000);
		 page.setUserpass("capg1234");
		 Thread.sleep(1000);
		 page.setButton();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		driver.navigate().to("file:///D:\\Users\\twinagra\\Desktop\\mvc-project\\eclipse-workspace\\fghfcgh\\src\\main\\webapp\\hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^user leaves userName blank$")
	public void user_leaves_userName_blank() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.setUsername("");
		
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		page.setButton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		  String alertMessage=driver.findElement(By.id("userErrMsg")).getText();
		  Thread.sleep(1000);
		  System.out.println("******" + alertMessage);
	}

	@When("^user leaves password blank and clicks the button$")
	public void user_leaves_password_blank_and_clicks_the_button() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.setUserpass("");
		 Thread.sleep(1000);
		 page.setButton();
	}

	@When("^user enters incorrect userName$")
	public void user_enters_incorrect_userName() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		page.setUsername("hgfhg");
		 Thread.sleep(1000);
	}

	@When("^user enters incorrect password$")
	public void user_enters_incorrect_password() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		page.setUserpass("cfdjbf");
		 Thread.sleep(1000);
	}

@After
public void tearDown() {
	driver.close();
}


}
