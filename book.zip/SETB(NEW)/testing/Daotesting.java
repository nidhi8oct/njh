import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.bean.Product;
import com.capgemini.dao.ProductDAO;

public class Daotesting {
	
	
	private ProductDAO dao;
	
	@Before
	public void setup()
	{
		System.out.println("setting up dao object");
		dao=new ProductDAO();
	}
	

	@Test
	public void test()
	{
		//fail("Not yet implemented");
		Product pro=new Product(0, 0, 0, 0);
		pro.getProduct_category();
		pro.getProduct_name();
		pro.getProduct_price();
		//asserTrue(True);
		
	}
	
	public void teardown()
	{
		System.out.println("cleaning up dao object");
		dao=null;
	}

}
