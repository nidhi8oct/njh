package com.capgemini.bean;

public class Product {
	
	private int product_id;
	private int product_name;
	private int product_category;
	private int product_price;
	

	public Product(int i, String string, String string2, int j) {
		// TODO Auto-generated constructor stub
	}


	public Product(int product_id, int product_name, int product_category, int product_price) {
		super();
		this.product_id = product_id;
		this.product_name = product_name;
		this.product_category = product_category;
		this.product_price = product_price;
	}


	/**
	 * @return the product_id
	 */
	public int getProduct_id() {
		return product_id;
	}


	/**
	 * @param product_id the product_id to set
	 */
	public void setProduct_id(int product_id) {
		this.product_id = product_id;
	}


	/**
	 * @return the product_name
	 */
	public int getProduct_name() {
		return product_name;
	}


	/**
	 * @param product_name the product_name to set
	 */
	public void setProduct_name(int product_name) {
		this.product_name = product_name;
	}


	/**
	 * @return the product_category
	 */
	public int getProduct_category() {
		return product_category;
	}


	/**
	 * @param product_category the product_category to set
	 */
	public void setProduct_category(int product_category) {
		this.product_category = product_category;
	}


	/**
	 * @return the product_price
	 */
	public int getProduct_price() {
		return product_price;
	}


	/**
	 * @param product_price the product_price to set
	 */
	public void setProduct_price(int product_price) {
		this.product_price = product_price;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Product [product_id=" + product_id + ", product_name=" + product_name + ", product_category="
				+ product_category + ", product_price=" + product_price + "]";
	}
	

}
