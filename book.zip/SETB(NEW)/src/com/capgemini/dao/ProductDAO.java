package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.bean.Product;
import com.capgemini.util.CollectionUtil;

public class ProductDAO implements IProductDAO
{
	
   Product pref=null;
 //  CollectionUtil ui=new CollectionUtil();
	

	@Override
	public  Product getProductDetails(int productCode)
	{
	   List<Product> product1 =new ArrayList <>(CollectionUtil.getproduct());
	   for(Product p:product1)
	   {
		   if(p.getProduct_id()== productCode)
		   {
			   return p;
		   }
	   }
	return pref;
	   
}
}