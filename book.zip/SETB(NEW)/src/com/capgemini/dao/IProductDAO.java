package com.capgemini.dao;

import com.capgemini.bean.Product;

public interface IProductDAO {
	Product getProductDetails(int productCode);
	

}
