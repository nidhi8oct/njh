package com.capgemini.service;

import com.capgemini.bean.Product;

public interface IProductService {
	Product getProductDetails(int productCode);

}
