package com.capgemini.service;

import com.capgemini.bean.Product;
import com.capgemini.dao.IProductDAO;
import com.capgemini.dao.ProductDAO;

public class ProductService implements IProductService
{

	IProductDAO dao=(IProductDAO) new ProductDAO();
	@Override
	
	public Product getProductDetails(int productCode) 
	{
		return dao.getProductDetails(productCode);
		
	}

}
