package com.capgemini.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.bean.Product;

public class CollectionUtil {

	private static Map<Integer,Product> products=new HashMap<Integer,Product>();
	static
	{
		products.put(1002, new Product(1001,"iPhone","electronics",35000));
		products.put(1001, new Product(1002,"LEDTV","electronics",45000));
		products.put(1003, new Product(1003,"Teddy","toys",800));
		products.put(1004, new Product(1004,"Telescope","toys",5000));
		
	}
	//to print value of product code
	//in this value is stored in key and value format so in daoimpl for fetchingthis we can create list for retrieving value
	public static List getproduct() {
		List<Product> product=new ArrayList<>(products.values());
		return product;
		
		
		// TODO Auto-generated method stub
		
		
	}
	
}
