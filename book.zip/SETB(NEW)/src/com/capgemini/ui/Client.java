package com.capgemini.ui;

import java.util.Scanner;

import com.capgemini.bean.Product;
import com.capgemini.service.IProductService;
import com.capgemini.service.ProductService;
import com.capgemini.util.*;

public class Client {

public static void main(String args[])
{
	IProductService ser=new ProductService();
	Scanner sc=new Scanner(System.in);
    System.out.println("press 1:generate bill by entering product code and quantity");
    System.out.println("press 2:exit");
    
    int ch=sc.nextInt();
    switch(ch)
    {
    case 1:System.out.println("enter product code");
            String pcode=sc.next();
            if(pcode.length()<=3) 
          {
        	  System.out.println("enter valid product code");
          }
         
            System.out.println("enter product quantity");
             int qty=sc.nextInt();
             if(qty<=0) 
             {
        	  System.out.println("enter valid quantity");
             }
             System.out.println("enter product name");
             String pname=sc.next();
             
             System.out.println("enter product category");
             String pcat=sc.next();
             
             System.out.println("enter product description");
             String pdesc=sc.next();
             
             System.out.println("enter product price");
             int pprice=sc.nextInt();
             float linetotal=pprice*qty;
             System.out.println("linetotal is"+linetotal);
             
             Product  pref;
             int productCode = 0;
		     pref=ser.getProductDetails(productCode);
		     if(pref==null)
		     {
		    	 System.out.println("sorry the product <<product code>> is not available");
		     }
		     else
		     {
		    	 return;
		     }
		     break;
		     
    case 2:
    	System.exit(0);
    	break;
    	
           
             
             
          
           
    }
    
    

	
	
	
	
	
	
}
}
