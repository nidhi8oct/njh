package com.capgemini.repo;

import com.capgemini.beans.Account;

public class AccountRepoImpl implements AccountRepo {

	@Override
	public boolean saveAccount(Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account searchAccount(int accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

}
