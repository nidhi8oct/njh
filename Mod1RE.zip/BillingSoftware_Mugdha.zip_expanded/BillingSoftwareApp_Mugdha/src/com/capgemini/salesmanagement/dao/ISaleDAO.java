package com.capgemini.salesmanagement.dao;

import java.util.HashMap;

import com.capgemini.salaesmanagement.bean.Sale;

public interface ISaleDAO {

	public HashMap<Integer,Sale>insertSalesDetails(Sale sale);

	
	
}
