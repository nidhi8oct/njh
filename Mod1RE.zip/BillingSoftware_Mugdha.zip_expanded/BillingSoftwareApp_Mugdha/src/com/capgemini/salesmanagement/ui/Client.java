package com.capgemini.salesmanagement.ui;

import java.util.List;
import java.util.Map;
import java.util.Scanner;


import com.capgemini.salaesmanagement.bean.Sale;
import com.capgemini.salaesmanagement.service.ISaleService;
import com.capgemini.salaesmanagement.service.SaleService;

public class Client {



		public static void main(String[] args) {
			ISaleService service=new SaleService();
			
			Scanner sc= new Scanner(System.in);
			System.out.println("Enter your choice \n 1.Enter Bill \n 2. Exit");
			int n=Integer.parseInt(sc.next());
			switch(n) {
			case 1:
			System.out.println("Enter Product Code");
			int pcode=Integer.parseInt(sc.next());
			if(service.validateProductCode(pcode)==false) {
				System.out.println("Enter a valid code");
				break;
			}
			System.out.println("Enter Product Quantity");
			int qty=Integer.parseInt(sc.next());
			if(service.validateQuantity(qty)==false) {
				System.out.println("Enter a valid qty");
				break;
			}
			System.out.println("Enter Product Category");
			String pcategory=sc.next();
			if(service.validateProductCat(pcategory)==false) {
				System.out.println("Enter a valid category");
				break;
			}
			System.out.println("Enter Product Name");
			String pname=sc.next();
			if(service.validateProductName(pname)==false) {
				System.out.println("Enter a valid name");
				break;
			}
			System.out.println("Enter Product Description");
			String pdes=sc.next();
			System.out.println("Enter Product Price");
			int price=Integer.parseInt(sc.next());
			if(service.validateProductPrice(price)==false) {
				System.out.println("Enter a valid price");
				break;
			}
			int id=(int) Math.random()*1000;
			Sale sale=new Sale();
			sale.setSaleId(id);
			sale.setProductName(pname);
			sale.setCategory(pcategory);
			sale.setProdCode(pcode);
			sale.setLineTotal(qty*price);
			sale.setQuantity(qty);
			sale.setDescription(pdes);
			sale.setPrice(price);
			service.insertSalesDetails(sale);
			System.out.println(id);
			System.out.println(sale.getProdCode());
			System.out.println(sale.getCategory());
			System.out.println(sale.getDescription());
			System.out.println(sale.getProductName());
			System.out.println(sale.getQuantity());
			System.out.println(sale.getPrice());
			System.out.println(sale.getLineTotal());
			break;
			case 2:
				System.exit(0);
			default:
				System.out.println("Enter valid choice");
		}}
}
