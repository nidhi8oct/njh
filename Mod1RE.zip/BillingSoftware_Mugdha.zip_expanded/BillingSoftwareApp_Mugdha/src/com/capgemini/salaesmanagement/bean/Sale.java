package com.capgemini.salaesmanagement.bean;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Random;

import com.capgemini.salaesmanagement.bean.*;

public class Sale {

	private int saleId;
	private int prodCode;
	private String productName;
	private String category;
	private LocalDate saleDate;
	private int quantity;
	private float lineTotal;
	private String description;
	private int price;
	
	/**
	 * @return the price
	 */
	public int getPrice() {
		return price;
	}
	/**
	 * @param price the price to set
	 */
	public void setPrice(int price) {
		this.price = price;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the saleId
	 */
	     
	
	public Sale()
	{
		super();
	}
	public int getSaleId() {
		return saleId;
	}
	/**
	 * @param saleId the saleId to set
	 */
	public void setSaleId(int saleId) {
		this.saleId = saleId;
	}
	/**
	 * @return the prodCode
	 */
	public int getProdCode() {
		return prodCode;
	}
	/**
	 * @param prodCode the prodCode to set
	 */
	public void setProdCode(int prodCode) {
		this.prodCode = prodCode;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	
	public Sale(int saleId, int prodCode, String category, String productName, LocalDate saleDate, int quantity,
			float lineTotal, String description, int price) {
		super();
		this.saleId = saleId;
		this.prodCode = prodCode;
		this.productName = productName;
		this.category = category;
		this.saleDate = saleDate;
		this.quantity = quantity;
		this.lineTotal = lineTotal;
		this.description = description;
		this.price = price;
	}
	/**
	 * @return the category
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category the category to set
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	/**
	 * @return the saleDate
	 */
	public LocalDate getSaleDate() {
		return saleDate;
	}
	/**
	 * @param saleDate the saleDate to set
	 */
	public void setSaleDate(LocalDate saleDate) {
		this.saleDate = saleDate;
	}
	/**
	 * @return the quantity
	 */
	public int getQuantity() {
		return quantity;
	}
	/**
	 * @param quantity the quantity to set
	 */
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	/**
	 * @return the lineTotal
	 */
	public float getLineTotal() {
		return lineTotal;
	}
	/**
	 * @param lineTotal the lineTotal to set
	 */
	public void setLineTotal(float lineTotal) {
		this.lineTotal =lineTotal;
	}
	
	public String toString() {
		return "Sales [saleId=" + saleId + ", prodCode=" + prodCode + ", prodName=" + productName + ", category="
				+ category + ", saleDate=" + saleDate + ", quantity=" + quantity + ", lineTotal=" + lineTotal
				+ "]";
	}
	
}
