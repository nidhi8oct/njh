package com.capgemini.practicedemo.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.practicedemo.dto.Shipwreck;
@Repository
@Transactional

public class ShipwreckRepositoryImpl implements ShipwreckRepository {
	@PersistenceContext
	private EntityManager entityManager;
	
	
	public List<Shipwreck> list() {
		Query query=entityManager.createQuery("Select wreck from Shipwreck wreck");
		return query.getResultList();
		// TODO Auto-generated method stub
		
	}

	@Override
	@Transactional
	public Shipwreck create(Shipwreck wreck) {
		// TODO Auto-generated method stub
		entityManager.persist(wreck);
		return wreck;
	}

	@Override
	public Shipwreck save(Shipwreck wreck, long id) {
		// TODO Auto-generated method stub
		return null;
	}

/*	@Override
	public Shipwreck update(Shipwreck wreck, long id) {
		// TODO Auto-generated method stub
		return null;
	}*/

	@Override
	public Shipwreck delete(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shipwreck get(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Shipwreck update(long id, Shipwreck shipwreck) {
		// TODO Auto-generated method stub
		return null;
	}


}
