package com.capgemini.practicedemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.practicedemo.dto.Shipwreck;
import com.capgemini.practicedemo.dto.ShipwreckStub;
import com.capgemini.practicedemo.repository.ShipwreckRepository;

import java.util.List;

@RestController
@RequestMapping("api/v1")

public class ShipwreckController
{
	
	@Autowired
	private ShipwreckRepository shipwreckRepo;
	
	@RequestMapping(method=RequestMethod.GET,value="shipwrecks")
	public List<Shipwreck>list(){
		return shipwreckRepo.list() ;
	}
		@RequestMapping(method=RequestMethod.POST,value="shipwrecks")
		public Shipwreck save(@RequestBody Shipwreck shipwreck)
		{
			return shipwreckRepo.create(shipwreck);
		}
		@RequestMapping(method=RequestMethod.GET,value="shipwrecks/{id}")
		public  Shipwreck get(@PathVariable(name="id")long id)
		{
			return shipwreckRepo.get(id);
			
		}
		@RequestMapping(method=RequestMethod.PUT,value="shipwrecks/{id}")
		public Shipwreck update(@RequestBody Shipwreck shipwreck,@PathVariable(name="id")long id)
		{
			return shipwreckRepo.update(id,shipwreck);
			
		}
		@RequestMapping(method=RequestMethod.DELETE,value="shipwrecks/{id}")
		public Shipwreck delete(@PathVariable(name="id")long id)
		{
			return shipwreckRepo.delete(id);
			
		}
		
	}

	


