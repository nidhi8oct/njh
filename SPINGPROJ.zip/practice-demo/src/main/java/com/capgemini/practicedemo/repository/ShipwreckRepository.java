package com.capgemini.practicedemo.repository;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.capgemini.practicedemo.dto.Shipwreck;

public interface ShipwreckRepository {
	public List<Shipwreck>list();
	public  Shipwreck create(Shipwreck wreck);
	public  Shipwreck save(Shipwreck wreck,long id);
	/*public Shipwreck update(Shipwreck wreck,long id);*/
	public Shipwreck delete(long id);
	public Shipwreck get(long id);
	public Shipwreck update(long id, Shipwreck shipwreck);

}
